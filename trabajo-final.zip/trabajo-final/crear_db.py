import sqlite3

conn = sqlite3.connect('tienda_gorras.db')
c = conn.cursor()
c.execute("INSERT INTO gorras (nombre, descripcion, precio, imagen) VALUES (?, ?, ?, ?)",
          ('Gorra de Muestra', 'Una gorra de ejemplo', 150000, 'img/muestra.jpg'))
conn.commit()
conn.close()

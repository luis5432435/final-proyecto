from flask import Flask, render_template, request
import sqlite3

app = Flask(__name__)

def obtener_productos():
    conn = sqlite3.connect('tienda_gorras.db')
    c = conn.cursor()
    c.execute('SELECT * FROM gorras')  
    productos = c.fetchall() 
    conn.close()
    return productos

@app.route('/')
def index():
    productos = obtener_productos() 
    return render_template('index.html', productos=productos)

if __name__ == "__main__":
    app.run(debug=True)
